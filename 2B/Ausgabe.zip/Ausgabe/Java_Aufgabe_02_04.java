package Ausgabe;
/*###################################################
 * Einsendeaufgabe 2.4
 * ################################################## */
public class Java_Aufgabe_02_04 {
	public static void main(String[] args){
		final int KILOMETER_IN_METER = 1000;
		final int METER_IN_ZENTIMETER = 100;
		System.out.println("Ein Kilometer entspricht " + KILOMETER_IN_METER + " Metern.");
		System.out.println("Ein Kilometer entspricht " + KILOMETER_IN_METER*METER_IN_ZENTIMETER + " Zentimetern.");
	}
}