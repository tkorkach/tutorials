package Ausgabe;
/*###################################################
 * Einsendeaufgabe 2.1
 * ################################################## */
public class Java_Aufgabe_02_01 {
	public static void main(String[] args) {
		System.out.println("\t\"");
		System.out.println("\t\"");
		System.out.println("#\t\t#");
		System.out.println("#\t\t#");
		System.out.println("#\t\t#");
		System.out.println("#\t\t#");
		System.out.println("#\t\t#");
		System.out.println("\t\"");
		System.out.println("\t\"");
		System.out.println("#\t\t#");
		System.out.println("#\t\t#");
		System.out.println("#\t\t#");
		System.out.println("#\t\t#");
		System.out.println("#\t\t#");
		System.out.println("\t\"");
		System.out.println("\t\"");
		
	}

}
