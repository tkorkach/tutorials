package Einsendeaufgabe03;
/*###################################################
 * Einsendeaufgabe 3.2
 * ################################################## */
public class Einsendeaufgabe03_02 {
	public static void main(String[] args) {
		for (int i=1; i<=50; i++)
		{
			System.out.print(i);
			if (i<50)
			System.out.print(",");
		}
	}
}
