package Einsendeaufgabe03;
/*###################################################
 * Einsendeaufgabe 3.3
 * ################################################## */

public class Einsendeaufgabe03_03 {
	public static void main (String[] args){
		int schleifenVariable = 1;
		while (schleifenVariable <= 100)
		{
			System.out.println(schleifenVariable*2);
			schleifenVariable++;
		}
	}
}
